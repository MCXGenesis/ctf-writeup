Pekerjaan bersih-bersih selesai.
